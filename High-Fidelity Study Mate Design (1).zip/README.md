
  # High-Fidelity Study Mate Design

  This is a code bundle for High-Fidelity Study Mate Design. The original project is available at https://www.figma.com/design/f7pcjozxUEZXn9U8tBbVh0/High-Fidelity-Study-Mate-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
import { useState, useMemo, useEffect } from 'react';
import { Search, Bell, Menu, FolderPlus, Upload } from 'lucide-react';
import { Sidebar } from './components/Sidebar';
import { BottomNav } from './components/BottomNav';
import { ActivityTracker } from './components/ActivityTracker';
import { FolderCard } from './components/FolderCard';
import { DeleteModal } from './components/DeleteModal';
import { CreateFolderModal } from './components/CreateFolderModal';
import { FileUploadModal } from './components/FileUploadModal';

interface FileItem {
  id: string;
  name: string;
  type: 'pdf' | 'docx' | 'png' | 'jpg';
  size: string;
  date: string;
}

interface Folder {
  id: string;
  name: string;
  files: FileItem[];
  color: string;
}

const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [createFolderOpen, setCreateFolderOpen] = useState(false);
  const [fileUploadOpen, setFileUploadOpen] = useState(false);
  const [deleteModal, setDeleteModal] = useState<{ 
    isOpen: boolean; 
    folderId: string; 
    fileId: string; 
    fileName: string;
    type: 'file' | 'folder';
  }>({
    isOpen: false,
    folderId: '',
    fileId: '',
    fileName: '',
    type: 'file',
  });

  // Weekly study data (hours per day)
  const [weeklyData, setWeeklyData] = useState(() => {
    const stored = localStorage.getItem('weeklyStudyData');
    if (stored) {
      return JSON.parse(stored);
    }
    return DAYS.map(day => ({ day, hours: 0 }));
  });

  const [todayStudySeconds, setTodayStudySeconds] = useState(0);

  // Update weekly data when timer updates
  useEffect(() => {
    const today = new Date().getDay(); // 0 = Sunday, 1 = Monday, etc.
    const dayIndex = today === 0 ? 6 : today - 1; // Convert to Mon=0, Sun=6
    
    const updatedWeeklyData = [...weeklyData];
    updatedWeeklyData[dayIndex] = {
      ...updatedWeeklyData[dayIndex],
      hours: parseFloat((todayStudySeconds / 3600).toFixed(2))
    };
    
    setWeeklyData(updatedWeeklyData);
    localStorage.setItem('weeklyStudyData', JSON.stringify(updatedWeeklyData));
  }, [todayStudySeconds]);

  const [folders, setFolders] = useState<Folder[]>([
    {
      id: '1',
      name: 'Computer Science',
      color: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      files: [
        { id: 'f1', name: 'Algorithms_Notes.pdf', type: 'pdf', size: '2.4 MB', date: 'Jan 8' },
        { id: 'f2', name: 'Data_Structures.docx', type: 'docx', size: '1.1 MB', date: 'Jan 7' },
        { id: 'f3', name: 'Diagram_BigO.png', type: 'png', size: '842 KB', date: 'Jan 6' },
      ],
    },
    {
      id: '2',
      name: 'Mathematics',
      color: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
      files: [
        { id: 'f4', name: 'Calculus_Formulas.pdf', type: 'pdf', size: '3.2 MB', date: 'Jan 5' },
        { id: 'f5', name: 'Statistics_Guide.docx', type: 'docx', size: '1.8 MB', date: 'Jan 4' },
      ],
    },
    {
      id: '3',
      name: 'Physics',
      color: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
      files: [
        { id: 'f6', name: 'Mechanics_Summary.pdf', type: 'pdf', size: '2.9 MB', date: 'Jan 3' },
      ],
    },
    {
      id: '4',
      name: 'Literature',
      color: 'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
      files: [],
    },
  ]);

  // Filter folders and files based on search query
  const filteredFolders = useMemo(() => {
    if (!searchQuery.trim()) return folders;
    
    const query = searchQuery.toLowerCase();
    return folders.map(folder => ({
      ...folder,
      files: folder.files.filter(file => 
        file.name.toLowerCase().includes(query)
      )
    })).filter(folder => 
      folder.name.toLowerCase().includes(query) || folder.files.length > 0
    );
  }, [folders, searchQuery]);

  const handleCreateFolder = (name: string, color: string) => {
    const newFolder: Folder = {
      id: Date.now().toString(),
      name,
      color,
      files: [],
    };
    setFolders([...folders, newFolder]);
  };

  const handleUploadFiles = (folderId: string, files: File[]) => {
    const newFiles: FileItem[] = files.map(file => {
      const ext = file.name.split('.').pop()?.toLowerCase() || 'pdf';
      const type = ['pdf', 'docx', 'png', 'jpg'].includes(ext) 
        ? ext as 'pdf' | 'docx' | 'png' | 'jpg' 
        : 'pdf';
      
      const formatFileSize = (bytes: number) => {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
      };

      return {
        id: `${Date.now()}_${Math.random()}`,
        name: file.name,
        type,
        size: formatFileSize(file.size),
        date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      };
    });

    setFolders(prevFolders =>
      prevFolders.map(folder =>
        folder.id === folderId
          ? { ...folder, files: [...folder.files, ...newFiles] }
          : folder
      )
    );
  };

  const handleDeleteFile = (folderId: string, fileId: string) => {
    const folder = folders.find(f => f.id === folderId);
    const file = folder?.files.find(f => f.id === fileId);
    
    if (file) {
      setDeleteModal({
        isOpen: true,
        folderId,
        fileId,
        fileName: file.name,
        type: 'file',
      });
    }
  };

  const handleDeleteFolder = (folderId: string) => {
    const folder = folders.find(f => f.id === folderId);
    
    if (folder) {
      setDeleteModal({
        isOpen: true,
        folderId,
        fileId: '',
        fileName: folder.name,
        type: 'folder',
      });
    }
  };

  const confirmDelete = () => {
    if (deleteModal.type === 'folder') {
      setFolders(prevFolders => prevFolders.filter(f => f.id !== deleteModal.folderId));
    } else {
      setFolders(prevFolders =>
        prevFolders.map(folder =>
          folder.id === deleteModal.folderId
            ? {
                ...folder,
                files: folder.files.filter(f => f.id !== deleteModal.fileId),
              }
            : folder
        )
      );
    }
    setDeleteModal({ isOpen: false, folderId: '', fileId: '', fileName: '', type: 'file' });
  };

  const handleTimeUpdate = (seconds: number) => {
    setTodayStudySeconds(seconds);
  };

  return (
    <div className="min-h-screen relative overflow-hidden pb-20">
      {/* Background with gradient */}
      <div
        className="fixed inset-0 -z-10"
        style={{
          background: 'linear-gradient(135deg, #F3E7FF 0%, #E8F5E9 50%, #E0F2F7 100%)',
        }}
      />

      {/* Sidebar Drawer */}
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />

      {/* Main Content */}
      <div className="min-h-screen">
        {/* Top Header */}
        <header className="px-4 py-4 flex items-center gap-3 sticky top-0 z-20"
          style={{
            background: 'rgba(255, 255, 255, 0.8)',
            backdropFilter: 'blur(20px)',
            borderBottom: '1px solid rgba(255, 255, 255, 0.5)',
          }}
        >
          <button
            onClick={() => setSidebarOpen(true)}
            className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{
              background: 'rgba(109, 91, 255, 0.1)',
            }}
          >
            <Menu className="w-5 h-5" style={{ color: '#6D5BFF' }} />
          </button>
          
          <div
            className="flex-1 px-4 py-2.5 rounded-2xl flex items-center gap-2"
            style={{
              background: 'rgba(255, 255, 255, 0.6)',
              backdropFilter: 'blur(20px)',
              border: '1px solid rgba(255, 255, 255, 0.7)',
            }}
          >
            <Search className="w-4 h-4 text-slate-400 flex-shrink-0" />
            <input
              type="text"
              placeholder="Search files..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 bg-transparent border-none outline-none text-slate-700 placeholder:text-slate-400 text-sm min-w-0"
            />
          </div>
          
          <button
            className="w-10 h-10 rounded-xl flex items-center justify-center relative flex-shrink-0"
            style={{
              background: 'rgba(255, 255, 255, 0.6)',
              backdropFilter: 'blur(20px)',
              border: '1px solid rgba(255, 255, 255, 0.7)',
            }}
          >
            <Bell className="w-4 h-4 text-slate-600" />
            <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full" />
          </button>
        </header>

        {/* Dashboard Content */}
        <main className="px-4 pb-6 pt-4">
          {/* Activity Tracker */}
          <div className="mb-6">
            <ActivityTracker weekData={weeklyData} onTimeUpdate={handleTimeUpdate} />
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 mb-4">
            <button
              onClick={() => setCreateFolderOpen(true)}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-white font-medium transition-all hover:shadow-lg active:scale-95"
              style={{
                background: 'linear-gradient(135deg, #6D5BFF 0%, #8B7AFF 100%)',
              }}
            >
              <FolderPlus className="w-5 h-5" />
              <span>New Folder</span>
            </button>
            <button
              onClick={() => setFileUploadOpen(true)}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-white font-medium transition-all hover:shadow-lg active:scale-95"
              style={{
                background: 'linear-gradient(135deg, #8B7AFF 0%, #A78BFF 100%)',
              }}
            >
              <Upload className="w-5 h-5" />
              <span>Upload</span>
            </button>
          </div>

          {/* Folders Section */}
          <div className="mb-4">
            <h2 className="text-xl font-semibold text-slate-800">
              {searchQuery ? 'Search Results' : 'My Folders'}
            </h2>
            {searchQuery && (
              <p className="text-sm text-slate-600 mt-1">
                {filteredFolders.length} folder(s) found
              </p>
            )}
          </div>

          <div className="space-y-4">
            {filteredFolders.map(folder => (
              <FolderCard
                key={folder.id}
                folder={folder}
                onDeleteFile={handleDeleteFile}
                onDeleteFolder={handleDeleteFolder}
              />
            ))}
            
            {filteredFolders.length === 0 && (
              <div className="text-center py-12">
                <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-slate-100 flex items-center justify-center">
                  <Search className="w-10 h-10 text-slate-400" />
                </div>
                <p className="text-slate-600 mb-2">No results found</p>
                <p className="text-sm text-slate-500">Try a different search term</p>
              </div>
            )}
          </div>
        </main>
      </div>

      {/* Bottom Navigation */}
      <BottomNav activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Modals */}
      <CreateFolderModal
        isOpen={createFolderOpen}
        onClose={() => setCreateFolderOpen(false)}
        onConfirm={handleCreateFolder}
      />

      <FileUploadModal
        isOpen={fileUploadOpen}
        onClose={() => setFileUploadOpen(false)}
        onConfirm={handleUploadFiles}
        folders={folders}
      />

      <DeleteModal
        isOpen={deleteModal.isOpen}
        onClose={() => setDeleteModal({ isOpen: false, folderId: '', fileId: '', fileName: '', type: 'file' })}
        onConfirm={confirmDelete}
        fileName={deleteModal.fileName}
        type={deleteModal.type}
      />
    </div>
  );
}

import { useState, useRef } from 'react';
import { ChevronDown, ChevronRight, Folder, FileText, FileImage, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface FileItem {
  id: string;
  name: string;
  type: 'pdf' | 'docx' | 'png' | 'jpg';
  size: string;
  date: string;
}

interface FolderCardProps {
  folder: {
    id: string;
    name: string;
    files: FileItem[];
    color: string;
  };
  onDeleteFile: (folderId: string, fileId: string) => void;
  onDeleteFolder: (folderId: string) => void;
}

export function FolderCard({ folder, onDeleteFile, onDeleteFolder }: FolderCardProps) {
  const [isExpanded, setIsExpanded] = useState(folder.id === '1');
  const longPressTimer = useRef<NodeJS.Timeout | null>(null);
  const fileLongPressTimer = useRef<NodeJS.Timeout | null>(null);

  const triggerHaptic = () => {
    // Vibration API for haptic feedback
    if ('vibrate' in navigator) {
      navigator.vibrate(50); // 50ms vibration
    }
  };

  const handleFolderLongPressStart = () => {
    longPressTimer.current = setTimeout(() => {
      triggerHaptic();
      onDeleteFolder(folder.id);
    }, 500); // 500ms long press
  };

  const handleFolderLongPressEnd = () => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
    }
  };

  const handleFileLongPressStart = (fileId: string) => {
    fileLongPressTimer.current = setTimeout(() => {
      triggerHaptic();
      onDeleteFile(folder.id, fileId);
    }, 500); // 500ms long press
  };

  const handleFileLongPressEnd = () => {
    if (fileLongPressTimer.current) {
      clearTimeout(fileLongPressTimer.current);
    }
  };

  const getFileIcon = (type: string) => {
    switch (type) {
      case 'pdf':
        return <FileText className="w-5 h-5" style={{ color: '#EF4444' }} />;
      case 'docx':
        return <FileText className="w-5 h-5" style={{ color: '#3B82F6' }} />;
      case 'png':
      case 'jpg':
        return <FileImage className="w-5 h-5" style={{ color: '#10B981' }} />;
      default:
        return <FileText className="w-5 h-5" />;
    }
  };

  const getFileColor = (type: string) => {
    switch (type) {
      case 'pdf':
        return 'rgba(239, 68, 68, 0.1)';
      case 'docx':
        return 'rgba(59, 130, 246, 0.1)';
      case 'png':
      case 'jpg':
        return 'rgba(16, 185, 129, 0.1)';
      default:
        return 'rgba(148, 163, 184, 0.1)';
    }
  };

  return (
    <div
      className="rounded-3xl overflow-hidden"
      style={{
        background: 'rgba(255, 255, 255, 0.4)',
        backdropFilter: 'blur(20px)',
        border: '1px solid rgba(255, 255, 255, 0.5)',
        boxShadow: '0 4px 16px rgba(0, 0, 0, 0.05)',
      }}
    >
      {/* Folder Header */}
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full px-4 py-4 flex items-center gap-3 hover:bg-white/20 transition-colors"
        onTouchStart={handleFolderLongPressStart}
        onTouchEnd={handleFolderLongPressEnd}
      >
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
          style={{ 
            background: folder.color,
            backdropFilter: 'blur(10px)',
          }}
        >
          <Folder className="w-5 h-5 text-white" />
        </div>
        <div className="flex-1 text-left min-w-0">
          <h4 className="text-slate-800 font-medium text-sm truncate">{folder.name}</h4>
          <p className="text-slate-500 text-xs">{folder.files.length} files</p>
        </div>
        {isExpanded ? (
          <ChevronDown className="w-5 h-5 text-slate-600 flex-shrink-0" />
        ) : (
          <ChevronRight className="w-5 h-5 text-slate-600 flex-shrink-0" />
        )}
      </button>

      {/* Files List */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="border-t border-white/30"
          >
            <div className="px-6 py-4 space-y-2">
              {folder.files.map((file, index) => (
                <motion.div
                  key={file.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/30 transition-all group"
                  style={{
                    background: getFileColor(file.type),
                  }}
                  onTouchStart={() => handleFileLongPressStart(file.id)}
                  onTouchEnd={handleFileLongPressEnd}
                >
                  <div className="flex-shrink-0">
                    {getFileIcon(file.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-slate-800 text-sm font-medium truncate">{file.name}</p>
                    <p className="text-slate-500 text-xs">
                      {file.size} • {file.date}
                    </p>
                  </div>
                  <button
                    onClick={() => onDeleteFile(folder.id, file.id)}
                    className="opacity-0 group-hover:opacity-100 transition-opacity p-2 hover:bg-red-100 rounded-lg"
                  >
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </button>
                </motion.div>
              ))}
              
              {folder.files.length === 0 && (
                <div className="py-8 text-center">
                  <div className="w-16 h-16 mx-auto mb-3 rounded-full bg-slate-100 flex items-center justify-center">
                    <Folder className="w-8 h-8 text-slate-400" />
                  </div>
                  <p className="text-slate-500 text-sm mb-2">This folder is empty</p>
                  <button className="text-xs text-purple-600 hover:text-purple-700 font-medium">
                    Drag & Drop files here
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}